#pragma once

struct MobHurtTimeComponent {
	int32_t hurtTime;
};