#pragma once

struct ActorEquipmentComponent {
    class SimpleContianer* mOffhandContainer;
    class SimpleContainer* mArmorContainer;
};