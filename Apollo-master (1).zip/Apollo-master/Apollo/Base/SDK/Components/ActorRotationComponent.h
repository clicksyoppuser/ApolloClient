#pragma once

struct ActorRotationComponent
{
	Vector2<float> rotation;
	Vector2<float> oldRotation;
};