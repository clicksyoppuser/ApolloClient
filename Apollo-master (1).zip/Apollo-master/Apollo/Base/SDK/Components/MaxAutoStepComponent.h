#pragma once

struct MaxAutoStepComponent {
public:
	float maxAutoStep;
};