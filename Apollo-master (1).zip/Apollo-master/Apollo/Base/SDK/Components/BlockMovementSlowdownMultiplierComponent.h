#pragma once

struct BlockMovementSlowdownMultiplierComponent {
	Vector3<float> blockMovementSlowdownMultiplier;
};