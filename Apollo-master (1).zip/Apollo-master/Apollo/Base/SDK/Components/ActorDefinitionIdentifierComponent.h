#pragma once

struct ActorDefinitionIdentifierComponent
{
	ActorDefinitionIdentifier identifier;
};