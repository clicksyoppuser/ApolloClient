#pragma once

struct ActorUniqueIDComponent {
    int64_t uniqueID;
};